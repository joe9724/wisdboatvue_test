<template>
  <ul class="sidebar-menu">
    <li class="header">设备管理</li>
    <router-link tag="li" class="pageLink" to="/myDevice">
      <a>
        <i class="fa fa-desktop"></i>
        <span class="page">我的设备</span>
      </a>
    </router-link>
    <router-link tag="li" class="pageLink" to="/devicelist">
      <a>
        <i class="fa fa-table"></i>
        <span class="page">设备列表</span>
      </a>
    </router-link>
    <li class="header">用户管理</li>
    <router-link tag="li" class="pageLink" to="/myDevice">
      <a>
        <i class="fa fa-desktop"></i>
        <span class="page">用户列表</span>
      </a>
    </router-link>
    <router-link tag="li" class="pageLink" to="/tables">
      <a>
        <i class="fa fa-table"></i>
        <span class="page">日志列表</span>
      </a>
    </router-link>
    <router-link tag="li" class="pageLink" to="/org">
      <a>
        <i class="fa fa-table"></i>
        <span class="page">组织机构</span>
      </a>
    </router-link>
    <router-link tag="li" class="pageLink" to="/curve">
      <a>
        <i class="fa fa-table"></i>
        <span class="page">曲线图</span>
      </a>
    </router-link>
    <router-link tag="li" class="pageLink" to="/air">
      <a>
        <i class="fa fa-table"></i>
        <span class="page">空气质量</span>
      </a>
    </router-link>
    <router-link tag="li" class="pageLink" to="/echart">
      <a>
        <i class="fa fa-table"></i>
        <span class="page">echart</span>
      </a>
    </router-link>
    <router-link tag="li" class="pageLink" to="/logout">
      <a>
        <i class="fa fa-table"></i>
        <span class="page">注销登录</span>
      </a>
    </router-link>
    <router-link tag="li" class="pageLink" to="/testtablepaging">
      <a>
        <i class="fa fa-table"></i>
        <span class="page">分页测试</span>
      </a>
    </router-link>


  </ul>
</template>
<script>
export default {
  name: 'SidebarName'
}
</script>
<style>
  /* override default */
  .sidebar-menu>li>a {
    padding: 12px 15px 12px 15px;
  }

  .sidebar-menu li.active>a>.fa-angle-left, .sidebar-menu li.active>a>.pull-right-container>.fa-angle-left {
    animation-name: rotate;
    animation-duration: .2s;
    animation-fill-mode: forwards;
  }

  @keyframes rotate {
    0% {
      transform: rotate(0deg);
    }

    100% {
      transform: rotate(-90deg);
    }
  }
</style>
