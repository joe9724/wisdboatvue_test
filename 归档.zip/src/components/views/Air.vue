<template>
  <!-- Main content -->
  <section class="content">
   waiting

  </section>
  <!-- /.content -->
</template>

<script>

</script>
<style>
.info-box {
  cursor: pointer;
}
.info-box-content {
  text-align: center;
  vertical-align: middle;
  display: inherit;
}
.fullCanvas {
  width: 100%;
}
</style>
