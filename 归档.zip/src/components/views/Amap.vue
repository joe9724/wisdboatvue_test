<template>
  <!-- Main content -->
  <section class="content">
    <el-amap vid="amapDemo" style="height: 400px">
    </el-amap>

  </section>
  <!-- /.content -->
</template>

<script>

</script>
<style>
.info-box {
  cursor: pointer;
}
.info-box-content {
  text-align: center;
  vertical-align: middle;
  display: inherit;
}
.fullCanvas {
  width: 100%;
}
</style>
